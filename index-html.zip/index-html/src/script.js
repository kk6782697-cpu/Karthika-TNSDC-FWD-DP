// Simple button click message

function showMessage() {

  alert("Thank you for your interest! Karthiga will contact you soon.");

}